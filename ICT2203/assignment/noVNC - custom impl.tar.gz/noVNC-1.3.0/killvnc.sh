vncserver -kill :1
fuser -k 80/tcp
