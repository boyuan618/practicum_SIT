<footer class="container">
    <p>Copyright &copy; 2020 World of Pets Pte. Ltd.</p>
</footer>