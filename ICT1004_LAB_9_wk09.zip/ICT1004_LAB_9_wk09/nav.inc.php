    <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img src="https://img14.360buyimg.com/n7/jfs/t20017/246/1164631408/408635/b218dd4f/5b175bfbN5d4827c1.jpg">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="./#dogs">Dogs</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="./#cats">Cats</a>
            </li>
            <li>
                <a class="nav-link" href="./register.php">Register</a>
            </li>
            <li>
                <a class="nav-link" href="./login.php">Login</a>
            </li>
            </ul>
        </div>
 
    </nav>